import numpy as np
import cv2
# import pyautogui as m
import sys
import time


def current_picture(current_time, start_time):
    sample_list = ["1.jpg", "2.jpg","3.jpg","tree.jpg"]
    iterator = int((current_time - start_time) / 5 )
    
    return sample_list[iterator]

k = 0


face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')#Replace this with the path where you reside the file
eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')#Replace this with the path where you reside the file
cap = cv2.VideoCapture(0)
# Change these parameters to play with sensitivity
c1 = 7
c2 = 5

start_time = time.time()
start_time = int(start_time)
while (True):
    # IMPORTANT 
    current_time = int(time.time())

    ret, img = cap.read()
    img = cv2.flip(img, 1)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    for (x, y, w, h) in faces:
        k = 1
        img = cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
        u1 = x + w
        u2 = y + h
        # print x + w / 2, y + h / 2
        #The below code is responsible for moving the mouse cursor in near real-time. Uncomment the below line to test it out.
        # m.moveTo(c1 * x + w / 2, c2 * y + h / 2, 0)
        roi_gray = gray[y:y + h, x:x + w]
        roi_color = img[y:y + h, x:x + w]
        eyes = eye_cascade.detectMultiScale(roi_gray, 1.3, 5)
        for (ex, ey, ew, eh) in eyes:
            k = 0
            cv2.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (255, 255, 0), 2)

    if k == 1:
        print("Blink")
        # print(int(current_time - start_time))
        # print(current_picture(current_time, start_time))
        # The below snippet is responsible for mouse click events. At the moment this is would work but still needs enhancements
        # uncomment the below to enable mouse left click events.
        # m.click()
    if k == 0:
        print("No Blink")
        # print(int(current_time - start_time))
        # print(current_picture(current_time, start_time))
    cv2.namedWindow("img", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("img", 600, 450)
    # slideshow 

    # current picture [STRING]
    pic = cv2.imread(current_picture(current_time, start_time),0)
    cv2.imshow('window', pic)

    # if(current_time > start_time + 5):
    #         pic = cv2.imread('test_marker3.jpg',0)
    #         cv2.imshow('window', pic)
    if cv2.waitKey(1) & 0xff == ord('q'):
        break

    if(current_time - start_time >= 19):
        start_time = current_time

    if(k == 1):
        if(current_picture(current_time, start_time) == "tree.jpg"):
            print("Login success")
            break
cap.release()
cv2.destroyAllWindows()

# eyeblink
Eyeblink detection and facial recognition using python and opencv

Required Modules:

1.Python 2.7.x

2.Numpy - pip install numpy

3.pyautogui - Mouse module for windows OS. This package is used to navigate mouse events.  Note this package is only for windows.

  pip install pyautogui

4.OpenCV

import numpy as np
import cv2
import cv2.aruco as aruco
import time



def current_picture(current_time, start_time):
	sample_list = ["cat", "dog","goat","cow"]
	iterator = int((current_time - start_time) / 5 )
	
	return sample_list[iterator]

start_time = int(time.time())
while (True):
	current_time = int(time.time())
	print(current_picture(current_time,start_time))
	if(current_time - start_time > 20):
		start_time = current_time